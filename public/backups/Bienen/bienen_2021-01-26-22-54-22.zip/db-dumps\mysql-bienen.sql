
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `actividades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `actividades` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `task` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha_vencimiento` date NOT NULL,
  `duracion_pro` int(11) DEFAULT NULL,
  `cant_personas` int(11) NOT NULL,
  `duracion_real` int(11) DEFAULT NULL,
  `dia` enum('Mié','Jue','Vie','Sáb','Dom','Lun','Mar') COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` enum('PM01','PM02','PM03','PM04') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PM01',
  `realizada` enum('Si','No') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'No',
  `observacion1` text COLLATE utf8mb4_unicode_ci,
  `observacion2` text COLLATE utf8mb4_unicode_ci,
  `id_planificacion` bigint(20) unsigned NOT NULL,
  `id_area` bigint(20) unsigned NOT NULL,
  `id_departamento` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `actividades_id_planificacion_foreign` (`id_planificacion`),
  KEY `actividades_id_area_foreign` (`id_area`),
  KEY `actividades_id_departamento_foreign` (`id_departamento`),
  CONSTRAINT `actividades_id_area_foreign` FOREIGN KEY (`id_area`) REFERENCES `areas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `actividades_id_departamento_foreign` FOREIGN KEY (`id_departamento`) REFERENCES `departamentos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `actividades_id_planificacion_foreign` FOREIGN KEY (`id_planificacion`) REFERENCES `planificacion` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `actividades` WRITE;
/*!40000 ALTER TABLE `actividades` DISABLE KEYS */;
INSERT INTO `actividades` VALUES (2,'prueba miercoles',NULL,'2020-12-24',NULL,22,NULL,'Jue','PM01','No',NULL,NULL,103,1,1,'2021-01-25 22:10:14','2021-01-25 22:10:14');
/*!40000 ALTER TABLE `actividades` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `actividades_adjuntos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `actividades_adjuntos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_actv_proceso` bigint(20) unsigned NOT NULL,
  `id_usuario` bigint(20) unsigned NOT NULL,
  `nombre` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` enum('img','file') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `actividades_adjuntos_id_usuario_foreign` (`id_usuario`),
  KEY `actividades_adjuntos_id_actv_proceso_foreign` (`id_actv_proceso`),
  CONSTRAINT `actividades_adjuntos_id_actv_proceso_foreign` FOREIGN KEY (`id_actv_proceso`) REFERENCES `actividades_proceso` (`id`) ON DELETE CASCADE,
  CONSTRAINT `actividades_adjuntos_id_usuario_foreign` FOREIGN KEY (`id_usuario`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `actividades_adjuntos` WRITE;
/*!40000 ALTER TABLE `actividades_adjuntos` DISABLE KEYS */;
/*!40000 ALTER TABLE `actividades_adjuntos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `actividades_comentarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `actividades_comentarios` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_actv_proceso` bigint(20) unsigned NOT NULL,
  `id_usuario` bigint(20) unsigned NOT NULL,
  `comentario` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `actividades_comentarios_id_usuario_foreign` (`id_usuario`),
  KEY `actividades_comentarios_id_actv_proceso_foreign` (`id_actv_proceso`),
  CONSTRAINT `actividades_comentarios_id_actv_proceso_foreign` FOREIGN KEY (`id_actv_proceso`) REFERENCES `actividades_proceso` (`id`) ON DELETE CASCADE,
  CONSTRAINT `actividades_comentarios_id_usuario_foreign` FOREIGN KEY (`id_usuario`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `actividades_comentarios` WRITE;
/*!40000 ALTER TABLE `actividades_comentarios` DISABLE KEYS */;
/*!40000 ALTER TABLE `actividades_comentarios` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `actividades_has_archivos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `actividades_has_archivos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_actividad` bigint(20) unsigned NOT NULL,
  `nombre` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` enum('img','file') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `actividades_has_archivos_id_actividad_foreign` (`id_actividad`),
  CONSTRAINT `actividades_has_archivos_id_actividad_foreign` FOREIGN KEY (`id_actividad`) REFERENCES `actividades` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `actividades_has_archivos` WRITE;
/*!40000 ALTER TABLE `actividades_has_archivos` DISABLE KEYS */;
/*!40000 ALTER TABLE `actividades_has_archivos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `actividades_proceso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `actividades_proceso` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_actividad` bigint(20) unsigned NOT NULL,
  `id_empleado` bigint(20) unsigned NOT NULL,
  `hora_inicio` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hora_finalizada` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('Iniciada','Finalizada') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Iniciada',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `actividades_proceso_id_empleado_foreign` (`id_empleado`),
  KEY `actividades_proceso_id_actividad_foreign` (`id_actividad`),
  CONSTRAINT `actividades_proceso_id_actividad_foreign` FOREIGN KEY (`id_actividad`) REFERENCES `actividades` (`id`) ON DELETE CASCADE,
  CONSTRAINT `actividades_proceso_id_empleado_foreign` FOREIGN KEY (`id_empleado`) REFERENCES `empleados` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `actividades_proceso` WRITE;
/*!40000 ALTER TABLE `actividades_proceso` DISABLE KEYS */;
/*!40000 ALTER TABLE `actividades_proceso` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `actividades_vistas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `actividades_vistas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_actividad` bigint(20) unsigned NOT NULL,
  `status` enum('Si','No') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `actividades_vistas_id_actividad_foreign` (`id_actividad`),
  CONSTRAINT `actividades_vistas_id_actividad_foreign` FOREIGN KEY (`id_actividad`) REFERENCES `actividades` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `actividades_vistas` WRITE;
/*!40000 ALTER TABLE `actividades_vistas` DISABLE KEYS */;
/*!40000 ALTER TABLE `actividades_vistas` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `afp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `afp` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `afp` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `afp` WRITE;
/*!40000 ALTER TABLE `afp` DISABLE KEYS */;
INSERT INTO `afp` VALUES (1,'AFP Capital',NULL,NULL),(2,'AFP Cuprum',NULL,NULL),(3,'AFP Habitat',NULL,NULL),(4,'AFP Modelo',NULL,NULL),(5,'AFP Planvital',NULL,NULL),(6,'AFP Provida',NULL,NULL);
/*!40000 ALTER TABLE `afp` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `areas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `areas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_gerencia` bigint(20) unsigned NOT NULL,
  `area` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ubicacion` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `areas_area_unique` (`area`),
  KEY `areas_id_gerencia_foreign` (`id_gerencia`),
  CONSTRAINT `areas_id_gerencia_foreign` FOREIGN KEY (`id_gerencia`) REFERENCES `gerencias` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `areas` WRITE;
/*!40000 ALTER TABLE `areas` DISABLE KEYS */;
INSERT INTO `areas` VALUES (1,1,'EWS','1D DCS Insp Estado SistCtrl 800xA Desal EWS','Planta Coloso-Antofagasta',NULL,NULL),(2,1,'Planta Cero/Desaladora & Acueducto','1D DCS Insp Estado SistCtrl 800xA Desal PLanta 0','Planta Coloso-Antofagasta',NULL,NULL),(3,1,'Agua y Tranque','Agua y Tranque','Feana-Mina',NULL,NULL),(4,2,'Filtro-Puerto','1D DCS Insp Estado SistCtrl 800xA Planta Filtro-Puerto','Planta Coloso-Antofagasta',NULL,NULL),(5,2,'ECT','1D DCS Insp Estado SistCtrl 800xA Planta ECT','Planta Coloso-Antofagasta',NULL,NULL),(6,2,'Los Colorados','DCS Insp Estado SistCtrl Bailey  Planta Los Colorados','Feana-Mina',NULL,NULL);
/*!40000 ALTER TABLE `areas` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `areas_empresa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `areas_empresa` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `area_e` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `areas_empresa` WRITE;
/*!40000 ALTER TABLE `areas_empresa` DISABLE KEYS */;
INSERT INTO `areas_empresa` VALUES (1,'Administración',NULL,NULL),(2,'Proyectos',NULL,NULL),(3,'Equipo MEL',NULL,NULL),(4,'Equipo BHP',NULL,NULL);
/*!40000 ALTER TABLE `areas_empresa` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `avisos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `avisos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `motivo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mensaje` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `dias_previos` int(11) NOT NULL,
  `dias_post` int(11) NOT NULL,
  `modalidad` enum('Automático','Manual','Ambos') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Automático',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `avisos` WRITE;
/*!40000 ALTER TABLE `avisos` DISABLE KEYS */;
INSERT INTO `avisos` VALUES (1,'Vencimiento de Licencia','Buenos días, Tardes o Noches. Le informamos que la fecha de vencimiento de su licencia esta llegando a la fecha, por lo que necesitamos que realice los procedimientos pertinentes para renovar su licencia, para poder continuar laborando dentro de nuestras instalaciones. Gracias por su atención, esperamos una respuesta lo más pronto posible.',5,5,'Automático',NULL,NULL),(2,'Vencimiento de Exámenes','Buenos días, Tardes o Noches. Le informamos que existen ciertos exámenes que debe realizarse como cumplimiento a las normativas de salubridad de nuestra empresa, por lo que necesitamos que realice los procedimientos pertinentes para entregar los resultados en la oficina pertinente, para poder continuar laborando dentro de nuestras instalaciones. Gracias por su atención, esperamos una respuesta lo más pronto posible.',5,5,'Ambos',NULL,NULL),(3,'Vencimiento de Cursos','Buenos días, Tardes o Noches. Le informamos que existen ciertos cursos que debe realizarse como cumplimiento a las normativas de nuestra empresa, por lo que necesitamos que realice los procedimientos pertinentes para entregar los resultados en la oficina pertinente, para poder continuar laborando dentro de nuestras instalaciones. Gracias por su atención, esperamos una respuesta lo más pronto posible.',30,10,'Ambos',NULL,NULL);
/*!40000 ALTER TABLE `avisos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `avisos_enviados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `avisos_enviados` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_aviso` bigint(20) unsigned NOT NULL,
  `id_empleado` bigint(20) unsigned NOT NULL,
  `status` enum('Enviado','Respondido','Respondido-Cumplido') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Enviado',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `avisos_enviados_id_aviso_foreign` (`id_aviso`),
  KEY `avisos_enviados_id_empleado_foreign` (`id_empleado`),
  CONSTRAINT `avisos_enviados_id_aviso_foreign` FOREIGN KEY (`id_aviso`) REFERENCES `avisos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `avisos_enviados_id_empleado_foreign` FOREIGN KEY (`id_empleado`) REFERENCES `empleados` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `avisos_enviados` WRITE;
/*!40000 ALTER TABLE `avisos_enviados` DISABLE KEYS */;
/*!40000 ALTER TABLE `avisos_enviados` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `comentarios_vistos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comentarios_vistos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_comentario` bigint(20) unsigned NOT NULL,
  `status` enum('Si','No') COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_actividad` int(11) NOT NULL,
  `id_empleado` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `comentarios_vistos_id_comentario_foreign` (`id_comentario`),
  CONSTRAINT `comentarios_vistos_id_comentario_foreign` FOREIGN KEY (`id_comentario`) REFERENCES `actividades_comentarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `comentarios_vistos` WRITE;
/*!40000 ALTER TABLE `comentarios_vistos` DISABLE KEYS */;
/*!40000 ALTER TABLE `comentarios_vistos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cursos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cursos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `curso` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('Activo','Inactivo') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Activo',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cursos` WRITE;
/*!40000 ALTER TABLE `cursos` DISABLE KEYS */;
INSERT INTO `cursos` VALUES (1,'Cero Daño MEL','Activo',NULL,NULL),(2,'Inducción de Area MEL','Activo',NULL,NULL),(3,'Hombre Nuevo Centinela','Activo',NULL,NULL),(4,'Altura','Activo',NULL,NULL),(5,'Inducción de Area Centinela','Activo',NULL,NULL),(6,'HCR30 Centinela','Activo',NULL,NULL),(7,'Primeros Auxilios Centinela','Activo',NULL,NULL),(8,'Extintores Centinela','Activo',NULL,NULL),(9,'Orientación en Prev. De Riesgos Centinela','Activo',NULL,NULL),(10,'Reg. De Emergencia Centinela','Activo',NULL,NULL),(11,'Servicio Salud Centinela','Activo',NULL,NULL),(12,'Aislación y Bloqueo Centinela','Activo',NULL,NULL);
/*!40000 ALTER TABLE `cursos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `datos_laborales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datos_laborales` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empleado` bigint(20) unsigned NOT NULL,
  `fechai_vac` date DEFAULT NULL,
  `fechaf_vac` date DEFAULT NULL,
  `status_vac` enum('Solicitadas','Aprobada','Negada','Sin Solicitar') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Sin Solicitar',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `datos_laborales_id_empleado_foreign` (`id_empleado`),
  CONSTRAINT `datos_laborales_id_empleado_foreign` FOREIGN KEY (`id_empleado`) REFERENCES `empleados` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `datos_laborales` WRITE;
/*!40000 ALTER TABLE `datos_laborales` DISABLE KEYS */;
INSERT INTO `datos_laborales` VALUES (1,2,'2019-12-17','2019-12-20','Solicitadas',NULL,NULL);
/*!40000 ALTER TABLE `datos_laborales` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `datos_varios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datos_varios` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empleado` bigint(20) unsigned NOT NULL,
  `segundo_nombre` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `segundo_apellido` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha_nac` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `datos_varios_id_empleado_foreign` (`id_empleado`),
  CONSTRAINT `datos_varios_id_empleado_foreign` FOREIGN KEY (`id_empleado`) REFERENCES `empleados` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `datos_varios` WRITE;
/*!40000 ALTER TABLE `datos_varios` DISABLE KEYS */;
INSERT INTO `datos_varios` VALUES (1,1,'José','Pérez','1996-11-30',NULL,NULL),(2,2,'Terreno','Terreno','1996-11-30',NULL,NULL),(3,3,'Portilla1','Portilla2','1996-11-30',NULL,NULL);
/*!40000 ALTER TABLE `datos_varios` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `departamentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `departamentos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `departamento` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `departamentos` WRITE;
/*!40000 ALTER TABLE `departamentos` DISABLE KEYS */;
INSERT INTO `departamentos` VALUES (1,'Ninguno',NULL,NULL),(2,'Comunicaciones',NULL,NULL),(3,'Mantención',NULL,NULL),(4,'Operación',NULL,NULL),(5,'Control de Procesos',NULL,NULL),(6,'DCS',NULL,NULL);
/*!40000 ALTER TABLE `departamentos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `empleados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `empleados` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` bigint(20) unsigned NOT NULL,
  `nombres` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellidos` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rut` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `edad` int(11) NOT NULL,
  `cargo` enum('Gerente','Jefe de Operaciones','Ingeniero de Servicios','Jefe de Administración','Técnico de Servicios','Ingeniero en Entrenamiento','Maestro Mayor','Jefe de Terreno','Supervisor de Terreno','Técnico de Montaje','Jefe de Coordinación y Gestión','Planificador','Prevención de Riesgos','Asistente Administrativo','Chofer') COLLATE utf8mb4_unicode_ci NOT NULL,
  `genero` enum('Masculino','Femenino') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Masculino',
  `status` enum('Activo','Reposo','Retirado') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Activo',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `empleados_email_unique` (`email`),
  KEY `empleados_id_usuario_foreign` (`id_usuario`),
  CONSTRAINT `empleados_id_usuario_foreign` FOREIGN KEY (`id_usuario`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `empleados` WRITE;
/*!40000 ALTER TABLE `empleados` DISABLE KEYS */;
INSERT INTO `empleados` VALUES (1,3,'María','Varas','m.varas@licancabur.cl','122456789',30,'Gerente','Masculino','Activo',NULL,NULL),(2,5,'Terreno','Terreno','terreno@licancabur.cl','123456789',30,'Gerente','Masculino','Activo',NULL,NULL),(3,1,'R','Portilla','r.portilla@licancabur.cl','12345189',30,'Gerente','Masculino','Activo',NULL,NULL);
/*!40000 ALTER TABLE `empleados` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `empleados_has_afp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `empleados_has_afp` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empleado` bigint(20) unsigned NOT NULL,
  `id_afp` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `empleados_has_afp_id_empleado_foreign` (`id_empleado`),
  KEY `empleados_has_afp_id_afp_foreign` (`id_afp`),
  CONSTRAINT `empleados_has_afp_id_afp_foreign` FOREIGN KEY (`id_afp`) REFERENCES `afp` (`id`) ON DELETE CASCADE,
  CONSTRAINT `empleados_has_afp_id_empleado_foreign` FOREIGN KEY (`id_empleado`) REFERENCES `empleados` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `empleados_has_afp` WRITE;
/*!40000 ALTER TABLE `empleados_has_afp` DISABLE KEYS */;
INSERT INTO `empleados_has_afp` VALUES (1,1,1,NULL,NULL),(2,1,2,NULL,NULL),(3,1,3,NULL,NULL),(4,1,4,NULL,NULL),(5,1,5,NULL,NULL),(6,1,6,NULL,NULL),(7,2,1,NULL,NULL),(8,2,2,NULL,NULL),(9,2,3,NULL,NULL),(10,2,4,NULL,NULL),(11,2,5,NULL,NULL),(12,2,6,NULL,NULL),(13,1,1,NULL,NULL),(14,1,2,NULL,NULL),(15,1,3,NULL,NULL),(16,1,4,NULL,NULL),(17,1,5,NULL,NULL),(18,1,6,NULL,NULL);
/*!40000 ALTER TABLE `empleados_has_afp` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `empleados_has_areas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `empleados_has_areas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empleado` bigint(20) unsigned NOT NULL,
  `id_area` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `empleados_has_areas_id_empleado_foreign` (`id_empleado`),
  KEY `empleados_has_areas_id_area_foreign` (`id_area`),
  CONSTRAINT `empleados_has_areas_id_area_foreign` FOREIGN KEY (`id_area`) REFERENCES `areas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `empleados_has_areas_id_empleado_foreign` FOREIGN KEY (`id_empleado`) REFERENCES `empleados` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `empleados_has_areas` WRITE;
/*!40000 ALTER TABLE `empleados_has_areas` DISABLE KEYS */;
INSERT INTO `empleados_has_areas` VALUES (1,1,1,NULL,NULL),(2,1,2,NULL,NULL),(3,1,3,NULL,NULL),(4,1,4,NULL,NULL),(5,1,5,NULL,NULL),(6,1,6,NULL,NULL),(7,2,1,NULL,NULL),(8,2,2,NULL,NULL),(9,2,4,NULL,NULL),(10,3,1,NULL,NULL),(11,3,2,NULL,NULL),(12,3,4,NULL,NULL);
/*!40000 ALTER TABLE `empleados_has_areas` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `empleados_has_areas_empresa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `empleados_has_areas_empresa` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empleado` bigint(20) unsigned NOT NULL,
  `id_area_e` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `empleados_has_areas_empresa_id_empleado_foreign` (`id_empleado`),
  KEY `empleados_has_areas_empresa_id_area_e_foreign` (`id_area_e`),
  CONSTRAINT `empleados_has_areas_empresa_id_area_e_foreign` FOREIGN KEY (`id_area_e`) REFERENCES `areas_empresa` (`id`) ON DELETE CASCADE,
  CONSTRAINT `empleados_has_areas_empresa_id_empleado_foreign` FOREIGN KEY (`id_empleado`) REFERENCES `empleados` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `empleados_has_areas_empresa` WRITE;
/*!40000 ALTER TABLE `empleados_has_areas_empresa` DISABLE KEYS */;
INSERT INTO `empleados_has_areas_empresa` VALUES (1,1,1,NULL,NULL),(2,1,2,NULL,NULL),(3,1,3,NULL,NULL),(4,1,4,NULL,NULL),(5,1,2,NULL,NULL),(6,3,3,NULL,NULL);
/*!40000 ALTER TABLE `empleados_has_areas_empresa` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `empleados_has_cursos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `empleados_has_cursos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empleado` bigint(20) unsigned NOT NULL,
  `id_curso` bigint(20) unsigned NOT NULL,
  `fecha` date DEFAULT NULL,
  `fecha_vence` date DEFAULT NULL,
  `status` enum('Entregado','Pendiente') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Entregado',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `empleados_has_cursos_id_empleado_foreign` (`id_empleado`),
  KEY `empleados_has_cursos_id_curso_foreign` (`id_curso`),
  CONSTRAINT `empleados_has_cursos_id_curso_foreign` FOREIGN KEY (`id_curso`) REFERENCES `cursos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `empleados_has_cursos_id_empleado_foreign` FOREIGN KEY (`id_empleado`) REFERENCES `empleados` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `empleados_has_cursos` WRITE;
/*!40000 ALTER TABLE `empleados_has_cursos` DISABLE KEYS */;
INSERT INTO `empleados_has_cursos` VALUES (1,1,1,'2019-01-15','2019-08-15','Entregado',NULL,NULL),(2,1,2,'2019-01-15','2019-08-15','Entregado',NULL,NULL),(3,1,3,'2019-01-15','2019-08-15','Entregado',NULL,NULL),(4,1,4,'2019-01-15','2019-08-15','Entregado',NULL,NULL),(5,1,5,'2019-01-15','2019-08-15','Entregado',NULL,NULL),(6,2,1,'2019-06-15','2019-01-15','Entregado',NULL,NULL),(7,2,2,'2019-06-15','2019-01-15','Entregado',NULL,NULL),(8,2,3,'2019-06-15','2019-01-15','Entregado',NULL,NULL),(9,2,4,'2019-06-15','2019-01-15','Entregado',NULL,NULL),(10,2,5,'2019-06-15','2019-01-15','Entregado',NULL,NULL);
/*!40000 ALTER TABLE `empleados_has_cursos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `empleados_has_departamentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `empleados_has_departamentos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empleado` bigint(20) unsigned NOT NULL,
  `id_departamento` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `empleados_has_departamentos_id_empleado_foreign` (`id_empleado`),
  KEY `empleados_has_departamentos_id_departamento_foreign` (`id_departamento`),
  CONSTRAINT `empleados_has_departamentos_id_departamento_foreign` FOREIGN KEY (`id_departamento`) REFERENCES `departamentos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `empleados_has_departamentos_id_empleado_foreign` FOREIGN KEY (`id_empleado`) REFERENCES `empleados` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `empleados_has_departamentos` WRITE;
/*!40000 ALTER TABLE `empleados_has_departamentos` DISABLE KEYS */;
INSERT INTO `empleados_has_departamentos` VALUES (1,1,2,NULL,NULL),(2,1,3,NULL,NULL),(3,1,4,NULL,NULL),(4,1,5,NULL,NULL),(5,1,6,NULL,NULL),(6,2,2,NULL,NULL),(7,2,4,NULL,NULL),(8,3,2,NULL,NULL),(9,3,4,NULL,NULL);
/*!40000 ALTER TABLE `empleados_has_departamentos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `empleados_has_examenes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `empleados_has_examenes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empleado` bigint(20) unsigned NOT NULL,
  `id_examen` bigint(20) unsigned NOT NULL,
  `fecha` date DEFAULT NULL,
  `fecha_vence` date DEFAULT NULL,
  `status` enum('Entregado','Pendiente') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Entregado',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `empleados_has_examenes_id_empleado_foreign` (`id_empleado`),
  KEY `empleados_has_examenes_id_examen_foreign` (`id_examen`),
  CONSTRAINT `empleados_has_examenes_id_empleado_foreign` FOREIGN KEY (`id_empleado`) REFERENCES `empleados` (`id`) ON DELETE CASCADE,
  CONSTRAINT `empleados_has_examenes_id_examen_foreign` FOREIGN KEY (`id_examen`) REFERENCES `examenes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `empleados_has_examenes` WRITE;
/*!40000 ALTER TABLE `empleados_has_examenes` DISABLE KEYS */;
INSERT INTO `empleados_has_examenes` VALUES (1,1,1,'2019-01-15','2019-08-15','Entregado',NULL,NULL),(2,1,2,'2019-01-15','2019-08-15','Entregado',NULL,NULL),(3,1,3,'2019-01-15','2019-08-15','Entregado',NULL,NULL),(4,1,4,'2019-01-15','2019-08-15','Entregado',NULL,NULL),(5,1,5,'2019-01-15','2019-08-15','Entregado',NULL,NULL),(6,2,1,'2019-06-15','2019-01-15','Entregado',NULL,NULL),(7,2,2,'2019-06-15','2019-01-15','Entregado',NULL,NULL),(8,2,3,'2019-06-15','2019-01-15','Entregado',NULL,NULL),(9,2,4,'2019-06-15','2019-01-15','Entregado',NULL,NULL),(10,2,5,'2019-06-15','2019-01-15','Entregado',NULL,NULL),(11,3,1,'2019-05-15',NULL,'Entregado',NULL,NULL),(12,3,2,'2019-05-15',NULL,'Entregado',NULL,NULL),(13,3,3,'2019-05-15',NULL,'Entregado',NULL,NULL),(14,3,4,'2019-05-15',NULL,'Entregado',NULL,NULL),(15,3,5,'2019-05-15',NULL,'Entregado',NULL,NULL);
/*!40000 ALTER TABLE `empleados_has_examenes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `empleados_has_faenas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `empleados_has_faenas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empleado` bigint(20) unsigned NOT NULL,
  `id_faena` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `empleados_has_faenas_id_empleado_foreign` (`id_empleado`),
  KEY `empleados_has_faenas_id_faena_foreign` (`id_faena`),
  CONSTRAINT `empleados_has_faenas_id_empleado_foreign` FOREIGN KEY (`id_empleado`) REFERENCES `empleados` (`id`) ON DELETE CASCADE,
  CONSTRAINT `empleados_has_faenas_id_faena_foreign` FOREIGN KEY (`id_faena`) REFERENCES `faenas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `empleados_has_faenas` WRITE;
/*!40000 ALTER TABLE `empleados_has_faenas` DISABLE KEYS */;
INSERT INTO `empleados_has_faenas` VALUES (1,1,1,NULL,NULL),(2,1,2,NULL,NULL),(3,1,3,NULL,NULL),(4,1,4,NULL,NULL),(5,2,1,NULL,NULL),(6,2,2,NULL,NULL),(7,3,4,NULL,NULL);
/*!40000 ALTER TABLE `empleados_has_faenas` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `empleados_has_isapre`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `empleados_has_isapre` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empleado` bigint(20) unsigned NOT NULL,
  `id_isapre` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `empleados_has_isapre_id_empleado_foreign` (`id_empleado`),
  KEY `empleados_has_isapre_id_isapre_foreign` (`id_isapre`),
  CONSTRAINT `empleados_has_isapre_id_empleado_foreign` FOREIGN KEY (`id_empleado`) REFERENCES `empleados` (`id`) ON DELETE CASCADE,
  CONSTRAINT `empleados_has_isapre_id_isapre_foreign` FOREIGN KEY (`id_isapre`) REFERENCES `isapre` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `empleados_has_isapre` WRITE;
/*!40000 ALTER TABLE `empleados_has_isapre` DISABLE KEYS */;
/*!40000 ALTER TABLE `empleados_has_isapre` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `empleados_has_licencias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `empleados_has_licencias` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empleado` bigint(20) unsigned NOT NULL,
  `id_licencia` bigint(20) unsigned NOT NULL,
  `fecha` date DEFAULT NULL,
  `fecha_vence` date DEFAULT NULL,
  `status` enum('Entregado','Pendiente') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Entregado',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `empleados_has_licencias_id_empleado_foreign` (`id_empleado`),
  KEY `empleados_has_licencias_id_licencia_foreign` (`id_licencia`),
  CONSTRAINT `empleados_has_licencias_id_empleado_foreign` FOREIGN KEY (`id_empleado`) REFERENCES `empleados` (`id`) ON DELETE CASCADE,
  CONSTRAINT `empleados_has_licencias_id_licencia_foreign` FOREIGN KEY (`id_licencia`) REFERENCES `licencias` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `empleados_has_licencias` WRITE;
/*!40000 ALTER TABLE `empleados_has_licencias` DISABLE KEYS */;
INSERT INTO `empleados_has_licencias` VALUES (1,1,1,'2018-04-01','2023-04-01','Entregado',NULL,NULL),(2,2,1,'2018-04-01','2023-04-01','Entregado',NULL,NULL),(3,3,1,'2018-04-01','2023-04-01','Entregado',NULL,NULL);
/*!40000 ALTER TABLE `empleados_has_licencias` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `examenes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `examenes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `examen` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `status` enum('Activo','Inactivo') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Activo',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `examenes` WRITE;
/*!40000 ALTER TABLE `examenes` DISABLE KEYS */;
INSERT INTO `examenes` VALUES (1,'Altura Geográfica',NULL,'Activo',NULL,NULL),(2,'Altura Física',NULL,'Activo',NULL,NULL),(3,'Adversión al riesgo',NULL,'Activo',NULL,NULL),(4,'Alcohol',NULL,'Activo',NULL,NULL),(5,'Drogas',NULL,'Activo',NULL,NULL),(6,'Psicosensométrico',NULL,'Activo',NULL,NULL);
/*!40000 ALTER TABLE `examenes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `faenas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faenas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `faena` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `faenas` WRITE;
/*!40000 ALTER TABLE `faenas` DISABLE KEYS */;
INSERT INTO `faenas` VALUES (1,'MEL',NULL,NULL),(2,'Centinela',NULL,NULL),(3,'SQM',NULL,NULL),(4,'R.T.',NULL,NULL);
/*!40000 ALTER TABLE `faenas` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `gerencias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gerencias` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gerencia` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `gerencias` WRITE;
/*!40000 ALTER TABLE `gerencias` DISABLE KEYS */;
INSERT INTO `gerencias` VALUES (1,'NPI',NULL,NULL),(2,'CHO',NULL,NULL);
/*!40000 ALTER TABLE `gerencias` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `informacion_contacto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `informacion_contacto` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empleado` bigint(20) unsigned NOT NULL,
  `nombre` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellido` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `direccion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `informacion_contacto_id_empleado_foreign` (`id_empleado`),
  CONSTRAINT `informacion_contacto_id_empleado_foreign` FOREIGN KEY (`id_empleado`) REFERENCES `empleados` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `informacion_contacto` WRITE;
/*!40000 ALTER TABLE `informacion_contacto` DISABLE KEYS */;
INSERT INTO `informacion_contacto` VALUES (1,1,'admin','admin','04121234567','admin@eiche.cl','no posee',NULL,NULL),(2,2,'admin','admin','04121234567','admin@eiche.cl','no posee',NULL,NULL),(3,3,'admin','admin','04121234567','admin@eiche.cl','no posee',NULL,NULL);
/*!40000 ALTER TABLE `informacion_contacto` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `isapre`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `isapre` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `isapre` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `isapre` WRITE;
/*!40000 ALTER TABLE `isapre` DISABLE KEYS */;
INSERT INTO `isapre` VALUES (1,'Banmédica S.A.',NULL,NULL),(2,'Chuquicamata Ltda.',NULL,NULL),(3,'Colmena Golden Cross S.A.',NULL,NULL),(4,'Consalud S.A.',NULL,NULL),(5,'Cruz Blanca S.A.',NULL,NULL),(6,'Cruz del Norte Ltda.',NULL,NULL),(7,'Nueva Masvida S.A.',NULL,NULL),(8,'Fundación Ltda.',NULL,NULL),(9,'Fusat Ltda.',NULL,NULL),(10,'Río Blanco Ltda.',NULL,NULL),(11,'San Lorenzo Ltda.',NULL,NULL),(12,'Vida Tres S.A.',NULL,NULL);
/*!40000 ALTER TABLE `isapre` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `licencias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `licencias` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `licencia` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('Activo','Inactivo') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Activo',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `licencias` WRITE;
/*!40000 ALTER TABLE `licencias` DISABLE KEYS */;
INSERT INTO `licencias` VALUES (1,'De Conducir','Activo',NULL,NULL);
/*!40000 ALTER TABLE `licencias` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_16_195341_create_gerencias_table',1),(4,'2019_08_18_153028_create_departamentos_table',1),(5,'2019_08_19_011947_create_areas_table',1),(6,'2019_08_19_012034_create_empleados_table',1),(7,'2019_08_19_152718_create_planificacion_table',1),(8,'2019_08_19_152728_create_actividades_table',1),(9,'2019_08_19_153125_create_actividades_has_archivos_table',1),(10,'2019_08_19_153622_create_actividades_proceso_table',1),(11,'2019_08_19_153911_create_actividades_comentarios_table',1),(12,'2019_08_19_154133_create_actividades_adjuntos_table',1),(13,'2019_09_27_214046_create_privilegios_table',1),(14,'2019_09_27_214409_create_usuarios_has_privilegios_table',1),(15,'2019_11_13_161958_create_comentarios_vistos_table',1),(16,'2019_11_13_162314_create_actividades_vistas_table',1),(17,'2019_11_21_153417_create_empleados_has_areas_table',1),(18,'2019_12_04_144106_create_empleados_has_departamentos',1),(19,'2019_12_16_125753_create_examenes_table',1),(20,'2019_12_16_125925_create_empleados_has_examenes_table',1),(21,'2019_12_16_130515_create_datos_laborales_table',1),(22,'2019_12_23_153808_create_notas_table',1),(23,'2020_01_08_124252_create_muros_table',1),(24,'2020_01_27_162422_create_novedades_table',1),(25,'2020_02_07_224328_create_avisos_table',1),(26,'2020_02_07_224643_create_avisos_enviados_table',1),(27,'2020_02_09_173336_create_cursos_table',1),(28,'2020_02_09_173421_create_empleados_has_cursos_table',1),(29,'2020_02_09_181746_create_areas_empresa_table',1),(30,'2020_02_09_181818_create_afp_table',1),(31,'2020_02_09_181846_create_faenas_table',1),(32,'2020_02_09_182032_create_empleados_has_areas_empresa_table',1),(33,'2020_02_09_182241_create_empleados_has_afp_table',1),(34,'2020_02_09_182303_create_empleados_has_faenas_table',1),(35,'2020_02_13_164635_create_informacion_contacto_table',1),(36,'2020_02_13_165154_create_datos_varios_table',1),(37,'2020_03_13_005852_create_licencias_table',1),(38,'2020_03_13_010111_create_empleados_has_licencias_table',1),(39,'2020_12_16_115917_create_isapre_table',1),(40,'2020_12_16_120407_create_empleados_has_isapre_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `muros`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `muros` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empleado` bigint(20) unsigned NOT NULL,
  `comentario` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha` date DEFAULT NULL,
  `hora` time DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `muros_id_empleado_foreign` (`id_empleado`),
  CONSTRAINT `muros_id_empleado_foreign` FOREIGN KEY (`id_empleado`) REFERENCES `empleados` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `muros` WRITE;
/*!40000 ALTER TABLE `muros` DISABLE KEYS */;
/*!40000 ALTER TABLE `muros` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `notas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_empleado` bigint(20) unsigned NOT NULL,
  `notas` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notas_id_empleado_foreign` (`id_empleado`),
  CONSTRAINT `notas_id_empleado_foreign` FOREIGN KEY (`id_empleado`) REFERENCES `empleados` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `notas` WRITE;
/*!40000 ALTER TABLE `notas` DISABLE KEYS */;
/*!40000 ALTER TABLE `notas` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `novedades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `novedades` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `titulo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `novedad` text COLLATE utf8mb4_unicode_ci,
  `tipo` enum('actividad','nuevo_user','notificacion','muro','EICHE') COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha` time NOT NULL,
  `hora` datetime NOT NULL,
  `id_usuario_n` bigint(20) unsigned DEFAULT NULL,
  `id_empleado` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `novedades_id_usuario_n_foreign` (`id_usuario_n`),
  KEY `novedades_id_empleado_foreign` (`id_empleado`),
  CONSTRAINT `novedades_id_empleado_foreign` FOREIGN KEY (`id_empleado`) REFERENCES `empleados` (`id`) ON DELETE CASCADE,
  CONSTRAINT `novedades_id_usuario_n_foreign` FOREIGN KEY (`id_usuario_n`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `novedades` WRITE;
/*!40000 ALTER TABLE `novedades` DISABLE KEYS */;
/*!40000 ALTER TABLE `novedades` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `planificacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `planificacion` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `elaborado` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `aprobado` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `num_contrato` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fechas` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `semana` int(11) NOT NULL,
  `anio` int(11) NOT NULL,
  `revision` enum('A','B','C','D') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'A',
  `id_gerencia` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `planificacion_id_gerencia_foreign` (`id_gerencia`),
  CONSTRAINT `planificacion_id_gerencia_foreign` FOREIGN KEY (`id_gerencia`) REFERENCES `gerencias` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=209 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `planificacion` WRITE;
/*!40000 ALTER TABLE `planificacion` DISABLE KEYS */;
INSERT INTO `planificacion` VALUES (1,'María José Varas','Gabriel Olmos','9100008366','01-01-2020 al 07-01-2020',1,2020,'A',1,NULL,NULL),(2,'María José Varas','Gabriel Olmos','9100008366','01-01-2020 al 07-01-2020',1,2020,'A',2,NULL,NULL),(3,'María José Varas','Gabriel Olmos','9100008366','08-01-2020 al 14-01-2020',2,2020,'A',1,NULL,NULL),(4,'María José Varas','Gabriel Olmos','9100008366','08-01-2020 al 14-01-2020',2,2020,'A',2,NULL,NULL),(5,'María José Varas','Gabriel Olmos','9100008366','15-01-2020 al 21-01-2020',3,2020,'A',1,NULL,NULL),(6,'María José Varas','Gabriel Olmos','9100008366','15-01-2020 al 21-01-2020',3,2020,'A',2,NULL,NULL),(7,'María José Varas','Gabriel Olmos','9100008366','22-01-2020 al 28-01-2020',4,2020,'A',1,NULL,NULL),(8,'María José Varas','Gabriel Olmos','9100008366','22-01-2020 al 28-01-2020',4,2020,'A',2,NULL,NULL),(9,'María José Varas','Gabriel Olmos','9100008366','29-01-2020 al 04-02-2020',5,2020,'A',1,NULL,NULL),(10,'María José Varas','Gabriel Olmos','9100008366','29-01-2020 al 04-02-2020',5,2020,'A',2,NULL,NULL),(11,'María José Varas','Gabriel Olmos','9100008366','05-02-2020 al 11-11-2020',6,2020,'A',1,NULL,NULL),(12,'María José Varas','Gabriel Olmos','9100008366','05-02-2020 al 11-11-2020',6,2020,'A',2,NULL,NULL),(13,'María José Varas','Gabriel Olmos','9100008366','12-02-2020 al 18-02-2020',7,2020,'A',1,NULL,NULL),(14,'María José Varas','Gabriel Olmos','9100008366','12-02-2020 al 18-02-2020',7,2020,'A',2,NULL,NULL),(15,'María José Varas','Gabriel Olmos','9100008366','19-02-2020 al 25-02-2020',8,2020,'A',1,NULL,NULL),(16,'María José Varas','Gabriel Olmos','9100008366','19-02-2020 al 25-02-2020',8,2020,'A',2,NULL,NULL),(17,'María José Varas','Gabriel Olmos','9100008366','26-02-2020 al 03-03-2020',9,2020,'A',1,NULL,NULL),(18,'María José Varas','Gabriel Olmos','9100008366','26-02-2020 al 03-03-2020',9,2020,'A',2,NULL,NULL),(19,'María José Varas','Gabriel Olmos','9100008366','04-03-2020 al 10-03-2020',10,2020,'A',1,NULL,NULL),(20,'María José Varas','Gabriel Olmos','9100008366','04-03-2020 al 10-03-2020',10,2020,'A',2,NULL,NULL),(21,'María José Varas','Gabriel Olmos','9100008366','11-03-2020 al 17-03-2020',11,2020,'A',1,NULL,NULL),(22,'María José Varas','Gabriel Olmos','9100008366','11-03-2020 al 17-03-2020',11,2020,'A',2,NULL,NULL),(23,'María José Varas','Gabriel Olmos','9100008366','18-03-2020 al 24-03-2020',12,2020,'A',1,NULL,NULL),(24,'María José Varas','Gabriel Olmos','9100008366','18-03-2020 al 24-03-2020',12,2020,'A',2,NULL,NULL),(25,'María José Varas','Gabriel Olmos','9100008366','25-03-2020 al 31-03-2020',13,2020,'A',1,NULL,NULL),(26,'María José Varas','Gabriel Olmos','9100008366','25-03-2020 al 31-03-2020',13,2020,'A',2,NULL,NULL),(27,'María José Varas','Gabriel Olmos','9100008366','01-04-2020 al 07-04-2020',14,2020,'A',1,NULL,NULL),(28,'María José Varas','Gabriel Olmos','9100008366','01-04-2020 al 07-04-2020',14,2020,'A',2,NULL,NULL),(29,'María José Varas','Gabriel Olmos','9100008366','08-04-2020 al 14-04-2020',15,2020,'A',1,NULL,NULL),(30,'María José Varas','Gabriel Olmos','9100008366','08-04-2020 al 14-04-2020',15,2020,'A',2,NULL,NULL),(31,'María José Varas','Gabriel Olmos','9100008366','15-04-2020 al 21-04-2020',16,2020,'A',1,NULL,NULL),(32,'María José Varas','Gabriel Olmos','9100008366','15-04-2020 al 21-04-2020',16,2020,'A',2,NULL,NULL),(33,'María José Varas','Gabriel Olmos','9100008366','22-04-2020 al 28-04-2020',17,2020,'A',1,NULL,NULL),(34,'María José Varas','Gabriel Olmos','9100008366','22-04-2020 al 28-04-2020',17,2020,'A',2,NULL,NULL),(35,'María José Varas','Gabriel Olmos','9100008366','29-04-2020 al 05-05-2020',18,2020,'A',1,NULL,NULL),(36,'María José Varas','Gabriel Olmos','9100008366','29-04-2020 al 05-05-2020',18,2020,'A',2,NULL,NULL),(37,'María José Varas','Gabriel Olmos','9100008366','06-05-2020 al 12-05-2020',19,2020,'A',1,NULL,NULL),(38,'María José Varas','Gabriel Olmos','9100008366','06-05-2020 al 12-05-2020',19,2020,'A',2,NULL,NULL),(39,'María José Varas','Gabriel Olmos','9100008366','13-05-2020 al 19-05-2020',20,2020,'A',1,NULL,NULL),(40,'María José Varas','Gabriel Olmos','9100008366','13-05-2020 al 19-05-2020',20,2020,'A',2,NULL,NULL),(41,'María José Varas','Gabriel Olmos','9100008366','20-05-2020 al 26-05-2020',21,2020,'A',1,NULL,NULL),(42,'María José Varas','Gabriel Olmos','9100008366','20-05-2020 al 26-05-2020',21,2020,'A',2,NULL,NULL),(43,'María José Varas','Gabriel Olmos','9100008366','27-05-2020 al 02-06-2020',22,2020,'A',1,NULL,NULL),(44,'María José Varas','Gabriel Olmos','9100008366','27-05-2020 al 02-06-2020',22,2020,'A',2,NULL,NULL),(45,'María José Varas','Gabriel Olmos','9100008366','03-06-2020 al 09-06-2020',23,2020,'A',1,NULL,NULL),(46,'María José Varas','Gabriel Olmos','9100008366','03-06-2020 al 09-06-2020',23,2020,'A',2,NULL,NULL),(47,'María José Varas','Gabriel Olmos','9100008366','10-06-2020 al 16-06-2020',24,2020,'A',1,NULL,NULL),(48,'María José Varas','Gabriel Olmos','9100008366','10-06-2020 al 16-06-2020',24,2020,'A',2,NULL,NULL),(49,'María José Varas','Gabriel Olmos','9100008366','17-06-2020 al 23-06-2020',25,2020,'A',1,NULL,NULL),(50,'María José Varas','Gabriel Olmos','9100008366','17-06-2020 al 23-06-2020',25,2020,'A',2,NULL,NULL),(51,'María José Varas','Gabriel Olmos','9100008366','24-06-2020 al 30-06-2020',26,2020,'A',1,NULL,NULL),(52,'María José Varas','Gabriel Olmos','9100008366','24-06-2020 al 30-06-2020',26,2020,'A',2,NULL,NULL),(53,'María José Varas','Gabriel Olmos','9100008366','01-07-2020 al 07-07-2020',27,2020,'A',1,NULL,NULL),(54,'María José Varas','Gabriel Olmos','9100008366','01-07-2020 al 07-07-2020',27,2020,'A',2,NULL,NULL),(55,'María José Varas','Gabriel Olmos','9100008366','08-07-2020 al 14-07-2020',28,2020,'A',1,NULL,NULL),(56,'María José Varas','Gabriel Olmos','9100008366','08-07-2020 al 14-07-2020',28,2020,'A',2,NULL,NULL),(57,'María José Varas','Gabriel Olmos','9100008366','15-07-2020 al 21-07-2020',29,2020,'A',1,NULL,NULL),(58,'María José Varas','Gabriel Olmos','9100008366','15-07-2020 al 21-07-2020',29,2020,'A',2,NULL,NULL),(59,'María José Varas','Gabriel Olmos','9100008366','22-07-2020 al 28-07-2020',30,2020,'A',1,NULL,NULL),(60,'María José Varas','Gabriel Olmos','9100008366','22-07-2020 al 28-07-2020',30,2020,'A',2,NULL,NULL),(61,'María José Varas','Gabriel Olmos','9100008366','29-07-2020 al 04-08-2020',31,2020,'A',1,NULL,NULL),(62,'María José Varas','Gabriel Olmos','9100008366','29-07-2020 al 04-08-2020',31,2020,'A',2,NULL,NULL),(63,'María José Varas','Gabriel Olmos','9100008366','05-08-2020 al 11-08-2020',32,2020,'A',1,NULL,NULL),(64,'María José Varas','Gabriel Olmos','9100008366','05-08-2020 al 11-08-2020',32,2020,'A',2,NULL,NULL),(65,'María José Varas','Gabriel Olmos','9100008366','12-08-2020 al 18-08-2020',33,2020,'A',1,NULL,NULL),(66,'María José Varas','Gabriel Olmos','9100008366','12-08-2020 al 18-08-2020',33,2020,'A',2,NULL,NULL),(67,'María José Varas','Gabriel Olmos','9100008366','19-08-2020 al 25-08-2020',34,2020,'A',1,NULL,NULL),(68,'María José Varas','Gabriel Olmos','9100008366','19-08-2020 al 25-08-2020',34,2020,'A',2,NULL,NULL),(69,'María José Varas','Gabriel Olmos','9100008366','26-08-2020 al 01-09-2020',35,2020,'A',1,NULL,NULL),(70,'María José Varas','Gabriel Olmos','9100008366','26-08-2020 al 01-09-2020',35,2020,'A',2,NULL,NULL),(71,'María José Varas','Gabriel Olmos','9100008366','02-09-2020 al 08-09-2020',36,2020,'A',1,NULL,NULL),(72,'María José Varas','Gabriel Olmos','9100008366','02-09-2020 al 08-09-2020',36,2020,'A',2,NULL,NULL),(73,'María José Varas','Gabriel Olmos','9100008366','09-09-2020 al 15-09-2020',37,2020,'A',1,NULL,NULL),(74,'María José Varas','Gabriel Olmos','9100008366','09-09-2020 al 15-09-2020',37,2020,'A',2,NULL,NULL),(75,'María José Varas','Gabriel Olmos','9100008366','16-09-2020 al 22-09-2020',38,2020,'A',1,NULL,NULL),(76,'María José Varas','Gabriel Olmos','9100008366','16-09-2020 al 22-09-2020',38,2020,'A',2,NULL,NULL),(77,'María José Varas','Gabriel Olmos','9100008366','23-09-2020 al 29-09-2020',39,2020,'A',1,NULL,NULL),(78,'María José Varas','Gabriel Olmos','9100008366','23-09-2020 al 29-09-2020',39,2020,'A',2,NULL,NULL),(79,'María José Varas','Gabriel Olmos','9100008366','30-09-2020 al 06-10-2020',40,2020,'A',1,NULL,NULL),(80,'María José Varas','Gabriel Olmos','9100008366','30-09-2020 al 06-10-2020',40,2020,'A',2,NULL,NULL),(81,'María José Varas','Gabriel Olmos','9100008366','07-10-2020 al 13-10-2020',41,2020,'A',1,NULL,NULL),(82,'María José Varas','Gabriel Olmos','9100008366','07-10-2020 al 13-10-2020',41,2020,'A',2,NULL,NULL),(83,'María José Varas','Gabriel Olmos','9100008366','14-10-2020 al 20-10-2020',42,2020,'A',1,NULL,NULL),(84,'María José Varas','Gabriel Olmos','9100008366','14-10-2020 al 20-10-2020',42,2020,'A',2,NULL,NULL),(85,'María José Varas','Gabriel Olmos','9100008366','21-10-2020 al 27-10-2020',43,2020,'A',1,NULL,NULL),(86,'María José Varas','Gabriel Olmos','9100008366','21-10-2020 al 27-10-2020',43,2020,'A',2,NULL,NULL),(87,'María José Varas','Gabriel Olmos','9100008366','28-10-2020 al 03-11-2020',44,2020,'A',1,NULL,NULL),(88,'María José Varas','Gabriel Olmos','9100008366','28-10-2020 al 03-11-2020',44,2020,'A',2,NULL,NULL),(89,'María José Varas','Gabriel Olmos','9100008366','04-11-2020 al 10-11-2020',45,2020,'A',1,NULL,NULL),(90,'María José Varas','Gabriel Olmos','9100008366','04-11-2020 al 10-11-2020',45,2020,'A',2,NULL,NULL),(91,'María José Varas','Gabriel Olmos','9100008366','11-11-2020 al 17-11-2020',46,2020,'A',1,NULL,NULL),(92,'María José Varas','Gabriel Olmos','9100008366','11-11-2020 al 17-11-2020',46,2020,'A',2,NULL,NULL),(93,'María José Varas','Gabriel Olmos','9100008366','18-11-2020 al 24-11-2020',47,2020,'A',1,NULL,NULL),(94,'María José Varas','Gabriel Olmos','9100008366','18-11-2020 al 24-11-2020',47,2020,'A',2,NULL,NULL),(95,'María José Varas','Gabriel Olmos','9100008366','25-11-2020 al 01-12-2020',48,2020,'A',1,NULL,NULL),(96,'María José Varas','Gabriel Olmos','9100008366','25-11-2020 al 01-12-2020',48,2020,'A',2,NULL,NULL),(97,'María José Varas','Gabriel Olmos','9100008366','02-12-2020 al 08-12-2020',49,2020,'A',1,NULL,NULL),(98,'María José Varas','Gabriel Olmos','9100008366','02-12-2020 al 08-12-2020',49,2020,'A',2,NULL,NULL),(99,'María José Varas','Gabriel Olmos','9100008366','09-12-2020 al 15-12-2020',50,2020,'A',1,NULL,NULL),(100,'María José Varas','Gabriel Olmos','9100008366','09-12-2020 al 15-12-2020',50,2020,'A',2,NULL,NULL),(101,'María José Varas','Gabriel Olmos','9100008366','16-12-2020 al 22-12-2020',51,2020,'A',1,NULL,NULL),(102,'María José Varas','Gabriel Olmos','9100008366','16-12-2020 al 22-12-2020',51,2020,'A',2,NULL,NULL),(103,'María José Varas','Gabriel Olmos','9100008366','23-12-2020 al 29-12-2020',52,2020,'A',1,NULL,NULL),(104,'María José Varas','Gabriel Olmos','9100008366','23-12-2020 al 29-12-2020',52,2020,'A',2,NULL,NULL),(105,'R Portilla','R Portilla','25364883','06-01-2021 al 12-01-2021',1,2021,'A',1,'2021-01-25 14:41:26','2021-01-25 14:41:26'),(107,'R Portilla','R Portilla','25364883','13-01-2021 al 19-01-2021',2,2021,'A',1,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(108,'R Portilla','R Portilla','25364883','13-01-2021 al 19-01-2021',2,2021,'A',2,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(109,'R Portilla','R Portilla','25364883','20-01-2021 al 26-01-2021',3,2021,'A',1,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(110,'R Portilla','R Portilla','25364883','20-01-2021 al 26-01-2021',3,2021,'A',2,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(111,'R Portilla','R Portilla','25364883','27-01-2021 al 02-02-2021',4,2021,'A',1,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(112,'R Portilla','R Portilla','25364883','27-01-2021 al 02-02-2021',4,2021,'A',2,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(113,'R Portilla','R Portilla','25364883','03-02-2021 al 09-02-2021',5,2021,'A',1,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(114,'R Portilla','R Portilla','25364883','03-02-2021 al 09-02-2021',5,2021,'A',2,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(115,'R Portilla','R Portilla','25364883','10-02-2021 al 16-02-2021',6,2021,'A',1,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(116,'R Portilla','R Portilla','25364883','10-02-2021 al 16-02-2021',6,2021,'A',2,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(117,'R Portilla','R Portilla','25364883','17-02-2021 al 23-02-2021',7,2021,'A',1,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(118,'R Portilla','R Portilla','25364883','17-02-2021 al 23-02-2021',7,2021,'A',2,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(119,'R Portilla','R Portilla','25364883','24-02-2021 al 02-03-2021',8,2021,'A',1,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(120,'R Portilla','R Portilla','25364883','24-02-2021 al 02-03-2021',8,2021,'A',2,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(121,'R Portilla','R Portilla','25364883','03-03-2021 al 09-03-2021',9,2021,'A',1,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(122,'R Portilla','R Portilla','25364883','03-03-2021 al 09-03-2021',9,2021,'A',2,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(123,'R Portilla','R Portilla','25364883','10-03-2021 al 16-03-2021',10,2021,'A',1,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(124,'R Portilla','R Portilla','25364883','10-03-2021 al 16-03-2021',10,2021,'A',2,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(125,'R Portilla','R Portilla','25364883','17-03-2021 al 23-03-2021',11,2021,'A',1,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(126,'R Portilla','R Portilla','25364883','17-03-2021 al 23-03-2021',11,2021,'A',2,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(127,'R Portilla','R Portilla','25364883','24-03-2021 al 30-03-2021',12,2021,'A',1,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(128,'R Portilla','R Portilla','25364883','24-03-2021 al 30-03-2021',12,2021,'A',2,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(129,'R Portilla','R Portilla','25364883','31-03-2021 al 06-04-2021',13,2021,'A',1,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(130,'R Portilla','R Portilla','25364883','31-03-2021 al 06-04-2021',13,2021,'A',2,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(131,'R Portilla','R Portilla','25364883','07-04-2021 al 13-04-2021',14,2021,'A',1,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(132,'R Portilla','R Portilla','25364883','07-04-2021 al 13-04-2021',14,2021,'A',2,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(133,'R Portilla','R Portilla','25364883','14-04-2021 al 20-04-2021',15,2021,'A',1,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(134,'R Portilla','R Portilla','25364883','14-04-2021 al 20-04-2021',15,2021,'A',2,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(135,'R Portilla','R Portilla','25364883','21-04-2021 al 27-04-2021',16,2021,'A',1,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(136,'R Portilla','R Portilla','25364883','21-04-2021 al 27-04-2021',16,2021,'A',2,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(137,'R Portilla','R Portilla','25364883','28-04-2021 al 04-05-2021',17,2021,'A',1,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(138,'R Portilla','R Portilla','25364883','28-04-2021 al 04-05-2021',17,2021,'A',2,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(139,'R Portilla','R Portilla','25364883','05-05-2021 al 11-05-2021',18,2021,'A',1,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(140,'R Portilla','R Portilla','25364883','05-05-2021 al 11-05-2021',18,2021,'A',2,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(141,'R Portilla','R Portilla','25364883','12-05-2021 al 18-05-2021',19,2021,'A',1,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(142,'R Portilla','R Portilla','25364883','12-05-2021 al 18-05-2021',19,2021,'A',2,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(143,'R Portilla','R Portilla','25364883','19-05-2021 al 25-05-2021',20,2021,'A',1,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(144,'R Portilla','R Portilla','25364883','19-05-2021 al 25-05-2021',20,2021,'A',2,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(145,'R Portilla','R Portilla','25364883','26-05-2021 al 01-06-2021',21,2021,'A',1,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(146,'R Portilla','R Portilla','25364883','26-05-2021 al 01-06-2021',21,2021,'A',2,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(147,'R Portilla','R Portilla','25364883','02-06-2021 al 08-06-2021',22,2021,'A',1,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(148,'R Portilla','R Portilla','25364883','02-06-2021 al 08-06-2021',22,2021,'A',2,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(149,'R Portilla','R Portilla','25364883','09-06-2021 al 15-06-2021',23,2021,'A',1,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(150,'R Portilla','R Portilla','25364883','09-06-2021 al 15-06-2021',23,2021,'A',2,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(151,'R Portilla','R Portilla','25364883','16-06-2021 al 22-06-2021',24,2021,'A',1,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(152,'R Portilla','R Portilla','25364883','16-06-2021 al 22-06-2021',24,2021,'A',2,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(153,'R Portilla','R Portilla','25364883','23-06-2021 al 29-06-2021',25,2021,'A',1,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(154,'R Portilla','R Portilla','25364883','23-06-2021 al 29-06-2021',25,2021,'A',2,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(155,'R Portilla','R Portilla','25364883','30-06-2021 al 06-07-2021',26,2021,'A',1,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(156,'R Portilla','R Portilla','25364883','30-06-2021 al 06-07-2021',26,2021,'A',2,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(157,'R Portilla','R Portilla','25364883','07-07-2021 al 13-07-2021',27,2021,'A',1,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(158,'R Portilla','R Portilla','25364883','07-07-2021 al 13-07-2021',27,2021,'A',2,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(159,'R Portilla','R Portilla','25364883','14-07-2021 al 20-07-2021',28,2021,'A',1,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(160,'R Portilla','R Portilla','25364883','14-07-2021 al 20-07-2021',28,2021,'A',2,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(161,'R Portilla','R Portilla','25364883','21-07-2021 al 27-07-2021',29,2021,'A',1,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(162,'R Portilla','R Portilla','25364883','21-07-2021 al 27-07-2021',29,2021,'A',2,'2021-01-25 14:41:27','2021-01-25 14:41:27'),(163,'R Portilla','R Portilla','25364883','28-07-2021 al 03-08-2021',30,2021,'A',1,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(164,'R Portilla','R Portilla','25364883','28-07-2021 al 03-08-2021',30,2021,'A',2,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(165,'R Portilla','R Portilla','25364883','04-08-2021 al 10-08-2021',31,2021,'A',1,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(166,'R Portilla','R Portilla','25364883','04-08-2021 al 10-08-2021',31,2021,'A',2,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(167,'R Portilla','R Portilla','25364883','11-08-2021 al 17-08-2021',32,2021,'A',1,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(168,'R Portilla','R Portilla','25364883','11-08-2021 al 17-08-2021',32,2021,'A',2,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(169,'R Portilla','R Portilla','25364883','18-08-2021 al 24-08-2021',33,2021,'A',1,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(170,'R Portilla','R Portilla','25364883','18-08-2021 al 24-08-2021',33,2021,'A',2,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(171,'R Portilla','R Portilla','25364883','25-08-2021 al 31-08-2021',34,2021,'A',1,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(172,'R Portilla','R Portilla','25364883','25-08-2021 al 31-08-2021',34,2021,'A',2,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(173,'R Portilla','R Portilla','25364883','01-09-2021 al 07-09-2021',35,2021,'A',1,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(174,'R Portilla','R Portilla','25364883','01-09-2021 al 07-09-2021',35,2021,'A',2,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(175,'R Portilla','R Portilla','25364883','08-09-2021 al 14-09-2021',36,2021,'A',1,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(176,'R Portilla','R Portilla','25364883','08-09-2021 al 14-09-2021',36,2021,'A',2,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(177,'R Portilla','R Portilla','25364883','15-09-2021 al 21-09-2021',37,2021,'A',1,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(178,'R Portilla','R Portilla','25364883','15-09-2021 al 21-09-2021',37,2021,'A',2,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(179,'R Portilla','R Portilla','25364883','22-09-2021 al 28-09-2021',38,2021,'A',1,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(180,'R Portilla','R Portilla','25364883','22-09-2021 al 28-09-2021',38,2021,'A',2,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(181,'R Portilla','R Portilla','25364883','29-09-2021 al 05-10-2021',39,2021,'A',1,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(182,'R Portilla','R Portilla','25364883','29-09-2021 al 05-10-2021',39,2021,'A',2,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(183,'R Portilla','R Portilla','25364883','06-10-2021 al 12-10-2021',40,2021,'A',1,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(184,'R Portilla','R Portilla','25364883','06-10-2021 al 12-10-2021',40,2021,'A',2,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(185,'R Portilla','R Portilla','25364883','13-10-2021 al 19-10-2021',41,2021,'A',1,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(186,'R Portilla','R Portilla','25364883','13-10-2021 al 19-10-2021',41,2021,'A',2,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(187,'R Portilla','R Portilla','25364883','20-10-2021 al 26-10-2021',42,2021,'A',1,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(188,'R Portilla','R Portilla','25364883','20-10-2021 al 26-10-2021',42,2021,'A',2,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(189,'R Portilla','R Portilla','25364883','27-10-2021 al 02-11-2021',43,2021,'A',1,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(190,'R Portilla','R Portilla','25364883','27-10-2021 al 02-11-2021',43,2021,'A',2,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(191,'R Portilla','R Portilla','25364883','03-11-2021 al 09-11-2021',44,2021,'A',1,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(192,'R Portilla','R Portilla','25364883','03-11-2021 al 09-11-2021',44,2021,'A',2,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(193,'R Portilla','R Portilla','25364883','10-11-2021 al 16-11-2021',45,2021,'A',1,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(194,'R Portilla','R Portilla','25364883','10-11-2021 al 16-11-2021',45,2021,'A',2,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(195,'R Portilla','R Portilla','25364883','17-11-2021 al 23-11-2021',46,2021,'A',1,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(196,'R Portilla','R Portilla','25364883','17-11-2021 al 23-11-2021',46,2021,'A',2,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(197,'R Portilla','R Portilla','25364883','24-11-2021 al 30-11-2021',47,2021,'A',1,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(198,'R Portilla','R Portilla','25364883','24-11-2021 al 30-11-2021',47,2021,'A',2,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(199,'R Portilla','R Portilla','25364883','01-12-2021 al 07-12-2021',48,2021,'A',1,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(200,'R Portilla','R Portilla','25364883','01-12-2021 al 07-12-2021',48,2021,'A',2,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(201,'R Portilla','R Portilla','25364883','08-12-2021 al 14-12-2021',49,2021,'A',1,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(202,'R Portilla','R Portilla','25364883','08-12-2021 al 14-12-2021',49,2021,'A',2,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(203,'R Portilla','R Portilla','25364883','15-12-2021 al 21-12-2021',50,2021,'A',1,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(204,'R Portilla','R Portilla','25364883','15-12-2021 al 21-12-2021',50,2021,'A',2,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(205,'R Portilla','R Portilla','25364883','22-12-2021 al 28-12-2021',51,2021,'A',1,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(206,'R Portilla','R Portilla','25364883','22-12-2021 al 28-12-2021',51,2021,'A',2,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(207,'R Portilla','R Portilla','25364883','29-12-2021 al 04-01-2022',52,2021,'A',1,'2021-01-25 14:41:28','2021-01-25 14:41:28'),(208,'R Portilla','R Portilla','25364883','29-12-2021 al 04-01-2022',52,2021,'A',2,'2021-01-25 14:41:28','2021-01-25 14:41:28');
/*!40000 ALTER TABLE `planificacion` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `privilegios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `privilegios` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `modulo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `privilegio` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `privilegios` WRITE;
/*!40000 ALTER TABLE `privilegios` DISABLE KEYS */;
INSERT INTO `privilegios` VALUES (1,'Planificación','Buscar',NULL,NULL),(2,'Planificación','Registrar',NULL,NULL),(3,'Planificación','Modificar',NULL,NULL),(4,'Planificación','Eliminar',NULL,NULL),(5,'Actividades','Ver',NULL,NULL),(6,'Actividades','Registrar',NULL,NULL),(7,'Actividades','Registro de PM03',NULL,NULL),(8,'Actividades','Modificar',NULL,NULL),(9,'Actividades','Asignar',NULL,NULL),(10,'Actividades','Eliminar',NULL,NULL),(11,'Usuarios','Listado',NULL,NULL),(12,'Usuarios','Registrar',NULL,NULL),(13,'Usuarios','Modificar',NULL,NULL),(14,'Usuarios','Eliminar',NULL,NULL),(15,'Usuarios','Ver datos laborales',NULL,NULL),(16,'Usuarios','Ver examenes',NULL,NULL),(17,'Usuarios','Ver curso cero daño',NULL,NULL),(18,'Graficas','Ver',NULL,NULL),(19,'Reportes','Excel',NULL,NULL),(20,'Reportes','PDF',NULL,NULL),(21,'Areas','Listado',NULL,NULL),(22,'Areas','Registrar',NULL,NULL),(23,'Areas','Editar',NULL,NULL),(24,'Areas','Eliminar',NULL,NULL),(25,'Gerencias','Listado',NULL,NULL),(26,'Gerencias','Registrar',NULL,NULL),(27,'Gerencias','Editar',NULL,NULL),(28,'Gerencias','Eliminar',NULL,NULL),(29,'Departamentos','Listado',NULL,NULL),(30,'Departamentos','Registrar',NULL,NULL),(31,'Departamentos','Editar',NULL,NULL),(32,'Departamentos','Eliminar',NULL,NULL),(33,'Actividades - PM01','General',NULL,NULL),(34,'Actividades - PM02','General',NULL,NULL),(35,'Actividades - PM04','General',NULL,NULL),(36,'Estadisticas','Por Ejecucion',NULL,NULL),(37,'Estadisticas','Por HH',NULL,NULL),(38,'Cursos','Listado',NULL,NULL),(39,'Cursos','Registrar',NULL,NULL),(40,'Cursos','Editar',NULL,NULL),(41,'Examenes','Listado',NULL,NULL),(42,'Examenes','Registrar',NULL,NULL),(43,'Examenes','Editar',NULL,NULL),(44,'Licencias','Listado',NULL,NULL),(45,'Licencias','Registrar',NULL,NULL),(46,'Licencias','Editar',NULL,NULL);
/*!40000 ALTER TABLE `privilegios` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_user` enum('Admin','Supervisor','Planificacion','Recursos humanos','Empleado','G-NPI','G-CHO') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Empleado',
  `superUser` enum('Eiche','no') COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'R Portilla','r.portilla@licancabur.cl',NULL,'$2y$10$fiplxSYwMoQW4mZmdxK5Au9NVxjR1xG2zX.ckXfFM5oG419lh3tUG','Admin','no',NULL,NULL,NULL),(2,'Gabriel Olmos','g.olmos@licancabur.cl',NULL,'$2y$10$8CvXnfEGTnLTZx5VvGcXHOp1qQxZg.yErBG9.EqvpxOrJdqT9VhMK','Supervisor','no',NULL,NULL,NULL),(3,'María José Varas','m.varas@licancabur.cl',NULL,'$2y$10$Iw6IhQ4YkV9Yw0TLEeROhe04bKjmN9Ws.K2ecKUCV0BwQNXB9Z6Qy','Planificacion','no',NULL,NULL,NULL),(4,'A Portilla','a.portilla@licancabur.cl',NULL,'$2y$10$j/8jZ8brxJgEy5LJtnVGmOmwFnNhljSItuQBfAkMTztGd7rqceWwi','Recursos humanos','no',NULL,NULL,NULL),(5,'Terreno','terreno@licancabur.cl',NULL,'$2y$10$KO72CqDD8yt389m4N5ukduun.ZvyIy2axjsau7JFMWvisi8OHjVYa','Empleado','no',NULL,NULL,NULL),(6,'Administrador EICHE','Admin@eiche.cl',NULL,'$2y$10$awC70HY4w3ZTCDHpSkAfjOv0Z6NJ24abQCaG8scs/VX20WoI1GGPC','Admin','Eiche',NULL,NULL,NULL),(7,'Licancabur','ViewMel@licancabur.cl',NULL,'$2y$10$1ZmkqdNkTNIvJrAjKJju1u0DL8yJ.kNYPS9xBFPk.oIxL7tbn39J2','Admin','no',NULL,NULL,NULL),(8,'MELNPI','melnpi@licancabur.cl',NULL,'$2y$10$hME0BEyEmwAnRR02dnINTe3jTGrHrq2QNs1upBu4Go5HC0pvL9DAa','G-NPI','no',NULL,NULL,NULL),(9,'MELCHO','melcho@licancabur.cl',NULL,'$2y$10$rZiV4b.8/qhtgvdr7KiaQuVHrtViDerWRHDZt4EErlYo29jTJsKKe','G-CHO','no',NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `usuarios_has_privilegios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuarios_has_privilegios` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` bigint(20) unsigned NOT NULL,
  `id_privilegio` bigint(20) unsigned NOT NULL,
  `status` enum('Si','No') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Si',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `usuarios_has_privilegios_id_usuario_foreign` (`id_usuario`),
  KEY `usuarios_has_privilegios_id_privilegio_foreign` (`id_privilegio`),
  CONSTRAINT `usuarios_has_privilegios_id_privilegio_foreign` FOREIGN KEY (`id_privilegio`) REFERENCES `privilegios` (`id`),
  CONSTRAINT `usuarios_has_privilegios_id_usuario_foreign` FOREIGN KEY (`id_usuario`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=415 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `usuarios_has_privilegios` WRITE;
/*!40000 ALTER TABLE `usuarios_has_privilegios` DISABLE KEYS */;
INSERT INTO `usuarios_has_privilegios` VALUES (1,1,1,'Si',NULL,NULL),(2,1,2,'Si',NULL,NULL),(3,1,3,'Si',NULL,NULL),(4,1,4,'Si',NULL,NULL),(5,1,5,'Si',NULL,NULL),(6,1,6,'Si',NULL,NULL),(7,1,7,'Si',NULL,NULL),(8,1,8,'Si',NULL,NULL),(9,1,9,'Si',NULL,NULL),(10,1,10,'Si',NULL,NULL),(11,1,11,'Si',NULL,NULL),(12,1,12,'Si',NULL,NULL),(13,1,13,'Si',NULL,NULL),(14,1,14,'Si',NULL,NULL),(15,1,15,'No',NULL,NULL),(16,1,16,'No',NULL,NULL),(17,1,17,'No',NULL,NULL),(18,1,18,'Si',NULL,NULL),(19,1,19,'Si',NULL,NULL),(20,1,20,'Si',NULL,NULL),(21,1,21,'Si',NULL,NULL),(22,1,22,'Si',NULL,NULL),(23,1,23,'Si',NULL,NULL),(24,1,24,'Si',NULL,NULL),(25,1,25,'Si',NULL,NULL),(26,1,26,'Si',NULL,NULL),(27,1,27,'Si',NULL,NULL),(28,1,28,'Si',NULL,NULL),(29,1,29,'Si',NULL,NULL),(30,1,30,'Si',NULL,NULL),(31,1,31,'Si',NULL,NULL),(32,1,32,'Si',NULL,NULL),(33,1,33,'Si',NULL,NULL),(34,1,34,'Si',NULL,NULL),(35,1,35,'Si',NULL,NULL),(36,1,36,'Si',NULL,NULL),(37,1,37,'Si',NULL,NULL),(38,1,38,'Si',NULL,NULL),(39,1,39,'Si',NULL,NULL),(40,1,40,'Si',NULL,NULL),(41,1,41,'Si',NULL,NULL),(42,1,42,'Si',NULL,NULL),(43,1,43,'Si',NULL,NULL),(44,1,44,'Si',NULL,NULL),(45,1,45,'Si',NULL,NULL),(46,1,46,'Si',NULL,NULL),(47,2,1,'Si',NULL,NULL),(48,2,2,'Si',NULL,NULL),(49,2,3,'Si',NULL,NULL),(50,2,4,'Si',NULL,NULL),(51,2,5,'Si',NULL,NULL),(52,2,6,'Si',NULL,NULL),(53,2,7,'Si',NULL,NULL),(54,2,8,'Si',NULL,NULL),(55,2,9,'Si',NULL,NULL),(56,2,10,'Si',NULL,NULL),(57,2,11,'No',NULL,NULL),(58,2,12,'No',NULL,NULL),(59,2,13,'No',NULL,NULL),(60,2,14,'No',NULL,NULL),(61,2,15,'No',NULL,NULL),(62,2,16,'No',NULL,NULL),(63,2,17,'Si',NULL,NULL),(64,2,18,'Si',NULL,NULL),(65,2,19,'Si',NULL,NULL),(66,2,20,'Si',NULL,NULL),(67,2,21,'Si',NULL,NULL),(68,2,22,'Si',NULL,NULL),(69,2,23,'Si',NULL,NULL),(70,2,24,'Si',NULL,NULL),(71,2,25,'Si',NULL,NULL),(72,2,26,'Si',NULL,NULL),(73,2,27,'Si',NULL,NULL),(74,2,28,'Si',NULL,NULL),(75,2,29,'Si',NULL,NULL),(76,2,30,'Si',NULL,NULL),(77,2,31,'Si',NULL,NULL),(78,2,32,'Si',NULL,NULL),(79,2,33,'Si',NULL,NULL),(80,2,34,'Si',NULL,NULL),(81,2,35,'Si',NULL,NULL),(82,2,36,'No',NULL,NULL),(83,2,37,'No',NULL,NULL),(84,2,38,'No',NULL,NULL),(85,2,39,'No',NULL,NULL),(86,2,40,'No',NULL,NULL),(87,2,41,'No',NULL,NULL),(88,2,42,'No',NULL,NULL),(89,2,43,'No',NULL,NULL),(90,2,44,'No',NULL,NULL),(91,2,45,'No',NULL,NULL),(92,2,46,'No',NULL,NULL),(93,3,1,'Si',NULL,NULL),(94,3,2,'Si',NULL,NULL),(95,3,3,'Si',NULL,NULL),(96,3,4,'Si',NULL,NULL),(97,3,5,'Si',NULL,NULL),(98,3,6,'Si',NULL,NULL),(99,3,7,'Si',NULL,NULL),(100,3,8,'Si',NULL,NULL),(101,3,9,'Si',NULL,NULL),(102,3,10,'Si',NULL,NULL),(103,3,11,'Si',NULL,NULL),(104,3,12,'Si',NULL,NULL),(105,3,13,'Si',NULL,NULL),(106,3,14,'Si',NULL,NULL),(107,3,15,'No',NULL,NULL),(108,3,16,'No',NULL,NULL),(109,3,17,'No',NULL,NULL),(110,3,18,'Si',NULL,NULL),(111,3,19,'Si',NULL,NULL),(112,3,20,'Si',NULL,NULL),(113,3,21,'Si',NULL,NULL),(114,3,22,'Si',NULL,NULL),(115,3,23,'Si',NULL,NULL),(116,3,24,'Si',NULL,NULL),(117,3,25,'Si',NULL,NULL),(118,3,26,'Si',NULL,NULL),(119,3,27,'Si',NULL,NULL),(120,3,28,'Si',NULL,NULL),(121,3,29,'Si',NULL,NULL),(122,3,30,'Si',NULL,NULL),(123,3,31,'Si',NULL,NULL),(124,3,32,'Si',NULL,NULL),(125,3,33,'Si',NULL,NULL),(126,3,34,'Si',NULL,NULL),(127,3,35,'Si',NULL,NULL),(128,3,36,'No',NULL,NULL),(129,3,37,'No',NULL,NULL),(130,3,38,'No',NULL,NULL),(131,3,39,'No',NULL,NULL),(132,3,40,'No',NULL,NULL),(133,3,41,'No',NULL,NULL),(134,3,42,'No',NULL,NULL),(135,3,43,'No',NULL,NULL),(136,3,44,'No',NULL,NULL),(137,3,45,'No',NULL,NULL),(138,3,46,'No',NULL,NULL),(139,4,1,'No',NULL,NULL),(140,4,2,'No',NULL,NULL),(141,4,3,'No',NULL,NULL),(142,4,4,'No',NULL,NULL),(143,4,5,'No',NULL,NULL),(144,4,6,'No',NULL,NULL),(145,4,7,'No',NULL,NULL),(146,4,8,'No',NULL,NULL),(147,4,9,'No',NULL,NULL),(148,4,10,'No',NULL,NULL),(149,4,11,'Si',NULL,NULL),(150,4,12,'Si',NULL,NULL),(151,4,13,'Si',NULL,NULL),(152,4,14,'Si',NULL,NULL),(153,4,15,'No',NULL,NULL),(154,4,16,'No',NULL,NULL),(155,4,17,'No',NULL,NULL),(156,4,18,'No',NULL,NULL),(157,4,19,'No',NULL,NULL),(158,4,20,'No',NULL,NULL),(159,4,21,'No',NULL,NULL),(160,4,22,'No',NULL,NULL),(161,4,23,'No',NULL,NULL),(162,4,24,'No',NULL,NULL),(163,4,25,'No',NULL,NULL),(164,4,26,'No',NULL,NULL),(165,4,27,'No',NULL,NULL),(166,4,28,'No',NULL,NULL),(167,4,29,'No',NULL,NULL),(168,4,30,'No',NULL,NULL),(169,4,31,'No',NULL,NULL),(170,4,32,'No',NULL,NULL),(171,4,33,'No',NULL,NULL),(172,4,34,'No',NULL,NULL),(173,4,35,'No',NULL,NULL),(174,4,36,'No',NULL,NULL),(175,4,37,'No',NULL,NULL),(176,4,38,'No',NULL,NULL),(177,4,39,'No',NULL,NULL),(178,4,40,'No',NULL,NULL),(179,4,41,'No',NULL,NULL),(180,4,42,'No',NULL,NULL),(181,4,43,'No',NULL,NULL),(182,4,44,'No',NULL,NULL),(183,4,45,'No',NULL,NULL),(184,4,46,'No',NULL,NULL),(185,5,1,'No',NULL,NULL),(186,5,2,'No',NULL,NULL),(187,5,3,'No',NULL,NULL),(188,5,4,'No',NULL,NULL),(189,5,5,'Si',NULL,NULL),(190,5,6,'Si',NULL,NULL),(191,5,7,'Si',NULL,NULL),(192,5,8,'No',NULL,NULL),(193,5,9,'No',NULL,NULL),(194,5,10,'No',NULL,NULL),(195,5,11,'No',NULL,NULL),(196,5,12,'No',NULL,NULL),(197,5,13,'No',NULL,NULL),(198,5,14,'No',NULL,NULL),(199,5,15,'No',NULL,NULL),(200,5,16,'No',NULL,NULL),(201,5,17,'No',NULL,NULL),(202,5,18,'No',NULL,NULL),(203,5,19,'No',NULL,NULL),(204,5,20,'Si',NULL,NULL),(205,5,21,'No',NULL,NULL),(206,5,22,'No',NULL,NULL),(207,5,23,'No',NULL,NULL),(208,5,24,'No',NULL,NULL),(209,5,25,'No',NULL,NULL),(210,5,26,'No',NULL,NULL),(211,5,27,'No',NULL,NULL),(212,5,28,'No',NULL,NULL),(213,5,29,'No',NULL,NULL),(214,5,30,'No',NULL,NULL),(215,5,31,'No',NULL,NULL),(216,5,32,'No',NULL,NULL),(217,5,33,'No',NULL,NULL),(218,5,34,'No',NULL,NULL),(219,5,35,'No',NULL,NULL),(220,5,36,'No',NULL,NULL),(221,5,37,'No',NULL,NULL),(222,5,38,'No',NULL,NULL),(223,5,39,'No',NULL,NULL),(224,5,40,'No',NULL,NULL),(225,5,41,'No',NULL,NULL),(226,5,42,'No',NULL,NULL),(227,5,43,'No',NULL,NULL),(228,5,44,'No',NULL,NULL),(229,5,45,'No',NULL,NULL),(230,5,46,'No',NULL,NULL),(231,6,1,'Si',NULL,NULL),(232,6,2,'Si',NULL,NULL),(233,6,3,'Si',NULL,NULL),(234,6,4,'Si',NULL,NULL),(235,6,5,'Si',NULL,NULL),(236,6,6,'Si',NULL,NULL),(237,6,7,'Si',NULL,NULL),(238,6,8,'Si',NULL,NULL),(239,6,9,'Si',NULL,NULL),(240,6,10,'Si',NULL,NULL),(241,6,11,'Si',NULL,NULL),(242,6,12,'Si',NULL,NULL),(243,6,13,'Si',NULL,NULL),(244,6,14,'Si',NULL,NULL),(245,6,15,'Si',NULL,NULL),(246,6,16,'Si',NULL,NULL),(247,6,17,'Si',NULL,NULL),(248,6,18,'Si',NULL,NULL),(249,6,19,'Si',NULL,NULL),(250,6,20,'Si',NULL,NULL),(251,6,21,'Si',NULL,NULL),(252,6,22,'Si',NULL,NULL),(253,6,23,'Si',NULL,NULL),(254,6,24,'Si',NULL,NULL),(255,6,25,'Si',NULL,NULL),(256,6,26,'Si',NULL,NULL),(257,6,27,'Si',NULL,NULL),(258,6,28,'Si',NULL,NULL),(259,6,29,'Si',NULL,NULL),(260,6,30,'Si',NULL,NULL),(261,6,31,'Si',NULL,NULL),(262,6,32,'Si',NULL,NULL),(263,6,33,'Si',NULL,NULL),(264,6,34,'Si',NULL,NULL),(265,6,35,'Si',NULL,NULL),(266,6,36,'Si',NULL,NULL),(267,6,37,'Si',NULL,NULL),(268,6,38,'Si',NULL,NULL),(269,6,39,'Si',NULL,NULL),(270,6,40,'Si',NULL,NULL),(271,6,41,'Si',NULL,NULL),(272,6,42,'Si',NULL,NULL),(273,6,43,'Si',NULL,NULL),(274,6,44,'Si',NULL,NULL),(275,6,45,'Si',NULL,NULL),(276,6,46,'Si',NULL,NULL),(277,7,1,'Si',NULL,NULL),(278,7,2,'Si',NULL,NULL),(279,7,3,'Si',NULL,NULL),(280,7,4,'Si',NULL,NULL),(281,7,5,'Si',NULL,NULL),(282,7,6,'Si',NULL,NULL),(283,7,7,'Si',NULL,NULL),(284,7,8,'Si',NULL,NULL),(285,7,9,'Si',NULL,NULL),(286,7,10,'Si',NULL,NULL),(287,7,11,'Si',NULL,NULL),(288,7,12,'Si',NULL,NULL),(289,7,13,'Si',NULL,NULL),(290,7,14,'Si',NULL,NULL),(291,7,15,'Si',NULL,NULL),(292,7,16,'Si',NULL,NULL),(293,7,17,'Si',NULL,NULL),(294,7,18,'Si',NULL,NULL),(295,7,19,'Si',NULL,NULL),(296,7,20,'Si',NULL,NULL),(297,7,21,'Si',NULL,NULL),(298,7,22,'Si',NULL,NULL),(299,7,23,'Si',NULL,NULL),(300,7,24,'Si',NULL,NULL),(301,7,25,'Si',NULL,NULL),(302,7,26,'Si',NULL,NULL),(303,7,27,'Si',NULL,NULL),(304,7,28,'Si',NULL,NULL),(305,7,29,'Si',NULL,NULL),(306,7,30,'Si',NULL,NULL),(307,7,31,'Si',NULL,NULL),(308,7,32,'Si',NULL,NULL),(309,7,33,'Si',NULL,NULL),(310,7,34,'Si',NULL,NULL),(311,7,35,'Si',NULL,NULL),(312,7,36,'Si',NULL,NULL),(313,7,37,'Si',NULL,NULL),(314,7,38,'Si',NULL,NULL),(315,7,39,'Si',NULL,NULL),(316,7,40,'Si',NULL,NULL),(317,7,41,'Si',NULL,NULL),(318,7,42,'Si',NULL,NULL),(319,7,43,'Si',NULL,NULL),(320,7,44,'Si',NULL,NULL),(321,7,45,'Si',NULL,NULL),(322,7,46,'Si',NULL,NULL),(323,8,1,'No',NULL,NULL),(324,8,2,'No',NULL,NULL),(325,8,3,'No',NULL,NULL),(326,8,4,'No',NULL,NULL),(327,8,5,'No',NULL,NULL),(328,8,6,'No',NULL,NULL),(329,8,7,'No',NULL,NULL),(330,8,8,'No',NULL,NULL),(331,8,9,'No',NULL,NULL),(332,8,10,'No',NULL,NULL),(333,8,11,'No',NULL,NULL),(334,8,12,'No',NULL,NULL),(335,8,13,'No',NULL,NULL),(336,8,14,'No',NULL,NULL),(337,8,15,'No',NULL,NULL),(338,8,16,'No',NULL,NULL),(339,8,17,'No',NULL,NULL),(340,8,18,'Si',NULL,NULL),(341,8,19,'Si',NULL,NULL),(342,8,20,'Si',NULL,NULL),(343,8,21,'No',NULL,NULL),(344,8,22,'No',NULL,NULL),(345,8,23,'No',NULL,NULL),(346,8,24,'No',NULL,NULL),(347,8,25,'No',NULL,NULL),(348,8,26,'No',NULL,NULL),(349,8,27,'No',NULL,NULL),(350,8,28,'No',NULL,NULL),(351,8,29,'No',NULL,NULL),(352,8,30,'No',NULL,NULL),(353,8,31,'No',NULL,NULL),(354,8,32,'No',NULL,NULL),(355,8,33,'No',NULL,NULL),(356,8,34,'No',NULL,NULL),(357,8,35,'No',NULL,NULL),(358,8,36,'Si',NULL,NULL),(359,8,37,'Si',NULL,NULL),(360,8,38,'No',NULL,NULL),(361,8,39,'No',NULL,NULL),(362,8,40,'No',NULL,NULL),(363,8,41,'No',NULL,NULL),(364,8,42,'No',NULL,NULL),(365,8,43,'No',NULL,NULL),(366,8,44,'No',NULL,NULL),(367,8,45,'No',NULL,NULL),(368,8,46,'No',NULL,NULL),(369,9,1,'No',NULL,NULL),(370,9,2,'No',NULL,NULL),(371,9,3,'No',NULL,NULL),(372,9,4,'No',NULL,NULL),(373,9,5,'No',NULL,NULL),(374,9,6,'No',NULL,NULL),(375,9,7,'No',NULL,NULL),(376,9,8,'No',NULL,NULL),(377,9,9,'No',NULL,NULL),(378,9,10,'No',NULL,NULL),(379,9,11,'No',NULL,NULL),(380,9,12,'No',NULL,NULL),(381,9,13,'No',NULL,NULL),(382,9,14,'No',NULL,NULL),(383,9,15,'No',NULL,NULL),(384,9,16,'No',NULL,NULL),(385,9,17,'No',NULL,NULL),(386,9,18,'Si',NULL,NULL),(387,9,19,'Si',NULL,NULL),(388,9,20,'Si',NULL,NULL),(389,9,21,'No',NULL,NULL),(390,9,22,'No',NULL,NULL),(391,9,23,'No',NULL,NULL),(392,9,24,'No',NULL,NULL),(393,9,25,'No',NULL,NULL),(394,9,26,'No',NULL,NULL),(395,9,27,'No',NULL,NULL),(396,9,28,'No',NULL,NULL),(397,9,29,'No',NULL,NULL),(398,9,30,'No',NULL,NULL),(399,9,31,'No',NULL,NULL),(400,9,32,'No',NULL,NULL),(401,9,33,'No',NULL,NULL),(402,9,34,'No',NULL,NULL),(403,9,35,'No',NULL,NULL),(404,9,36,'Si',NULL,NULL),(405,9,37,'Si',NULL,NULL),(406,9,38,'No',NULL,NULL),(407,9,39,'No',NULL,NULL),(408,9,40,'No',NULL,NULL),(409,9,41,'No',NULL,NULL),(410,9,42,'No',NULL,NULL),(411,9,43,'No',NULL,NULL),(412,9,44,'No',NULL,NULL),(413,9,45,'No',NULL,NULL),(414,9,46,'No',NULL,NULL);
/*!40000 ALTER TABLE `usuarios_has_privilegios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

